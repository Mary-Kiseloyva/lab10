# Report on the Laboratory work № 10
Made by Kirill Skofenko
### Use Case Diagram 
![](screenshots/useCase.png)
### Class Diagram 
![](screenshots/class.png)
