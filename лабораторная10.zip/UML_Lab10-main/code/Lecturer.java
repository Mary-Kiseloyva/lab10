public class Lecturer extends ResearchAssociate {

    public void makeCourseProgram() {

    }

    public void teachCourse() {

    }

    public void evaluateAcademicPerformance() {
        
    }
}