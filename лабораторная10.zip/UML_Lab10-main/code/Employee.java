public abstract class Employee {

	public int ssNo;
	public string name;
	public string email;
	public int counter;

}