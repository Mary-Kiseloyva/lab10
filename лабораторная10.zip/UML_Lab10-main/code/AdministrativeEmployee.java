public class AdministrativeEmployee extends Employee {

    public void createSchedule() {
        
    }

    public void superviseCourseConducting() {

    }
}