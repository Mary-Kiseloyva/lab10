public class Project {

	public string name;
	public Date start;
	public Date end;

}