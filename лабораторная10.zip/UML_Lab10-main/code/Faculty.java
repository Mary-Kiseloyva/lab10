public class Faculty {

	public Employee dean;
	public string name;

}