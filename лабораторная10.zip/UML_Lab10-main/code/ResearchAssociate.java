public class ResearchAssociate extends Employee {

	public string fieldOfStudy;

	public void findResearchFunding() {

	}

	public void doResearch() {
		
	}

}