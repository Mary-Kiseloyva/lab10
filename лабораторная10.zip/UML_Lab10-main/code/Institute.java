public class Institute {

	public string name;
	public string address;

}