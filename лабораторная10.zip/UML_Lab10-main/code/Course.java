import java.util.*;

public class Course {

	Collection<Lecturer> teaches;
	public string name;
	public int id;
	public float hours;

}